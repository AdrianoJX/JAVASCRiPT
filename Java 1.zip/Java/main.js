// Classe pour les personnages
class Personnage {
    constructor(nom, vie, attaque, precision) {
        this.nom = nom; // Le nom du personnage
        this.vie = vie; // Les points de vie
        this.attaque = attaque; // Les points d'attaque
        this.precision = precision; // La précision de l'attaque
    }

    attaquer(adversaire) {
        let chance = Math.random(); // Un nombre entre 0 et 1
        if (chance < this.precision) {
            console.log(this.nom + " attaque " + adversaire.nom + " et touche !");
            adversaire.vie = adversaire.vie - this.attaque;
            console.log(adversaire.nom + " perd " + this.attaque + " points de vie.");
        } else {
            console.log(this.nom + " attaque " + adversaire.nom + " mais rate !");
        }
    }
}

// Création des personnages
let perso1 = new Personnage("Chevalier", 50, 8, 0.6);
let perso2 = new Personnage("Barbare", 45, 10, 0.5);

console.log("Début du combat !");

while (perso1.vie > 0 && perso2.vie > 0) {
    perso1.attaquer(perso2); // Le premier attaque le second

    if (perso2.vie <= 0) {
        console.log(perso2.nom + " est KO ! " + perso1.nom + " gagne !");
        break;
    }

    perso2.attaquer(perso1); // Le second attaque le premier

    if (perso1.vie <= 0) {
        console.log(perso1.nom + " est KO ! " + perso2.nom + " gagne !");
        break;
    }

    // Affiche les points de vie après chaque tour
    console.log(perso1.nom + " a " + perso1.vie + " points de vie restants.");
    console.log(perso2.nom + " a " + perso2.vie + " points de vie restants.");
}

console.log("Fin du combat !");

